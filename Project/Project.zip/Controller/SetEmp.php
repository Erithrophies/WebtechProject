<?php
// Set role cookie to "hr"
setcookie("emp", 'true', time() + 3600, '/'); // expires in 1 hour
//echo "Role cookie set to HR. <a href='hr_dashboard.php'>Go to HR Dashboard</a>";
?>
