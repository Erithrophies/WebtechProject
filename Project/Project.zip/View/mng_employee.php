<?php
    session_start();
    if (isset($_COOKIE['status'])){
      //$role = $_COOKIE['emp'];
      if (isset($_COOKIE['hr'])){
        header('Location: HR_dashboard.php');}
        if (isset($_COOKIE['emp'])){
        header('Location: Employee_dashboard.php');}
        if (isset($_COOKIE['hr_d'])){
        header('Location: HR_document.php');}
        if (isset($_COOKIE['hr_emp'])){
        header('Location: HR_Employee.php');}
        if (isset($_COOKIE['hr_leave'])){
        header('Location: HR_leave.php');}
        if (isset($_COOKIE['emp_doc'])){
        header('Location: emp_document.php');}
        if (isset($_COOKIE['emp_emp'])){
        header('Location: Emp_employee.php');}
        if (isset($_COOKIE['emp_leave'])){
        header('Location: employee_leave.php');}
        if (isset($_COOKIE['hr_perfomance'])){
        header('Location: HR_perfomance.php');}
       if (isset($_COOKIE['mng'])){
       
        //header('Location: Employee_dashboard.php');
       
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  
  <style>
    * { box-sizing: border-box; }
    html, body {
      height: 100%;
      margin: 0;
      padding: 0;
    }
    body {
      min-height: 100vh;
      display: flex;
      font-family: Arial, sans-serif;
      background-color: rgb(249, 249, 249);
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
      color: white;
    }

    .container {
      display: flex;
      width: 100%;
      min-height: 100vh;
    }

    .main {
      flex: 1;
      padding: 30px;
      margin-left: 250px; 
    }

    .department-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .department-header button {
      background: none;
      border: none;
      color: white;
      font-size: 18px;
      cursor: pointer;
    }
    .department-list li {
      display: flex;
      align-items: center;
      gap: 10px;
      padding-left: 10px;
    }
    .circle {
      width: 10px;
      height: 10px;
      border-radius: 50%;
    }
    .art { background-color: #f78fb3; }
    .dev { background-color: #70a1ff; }
    .bottom-section {
      margin-top: auto;
    }

    .topbar {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      margin-bottom: 30px;
      gap: 20px;
    }
    .topbar .notification {
      font-size: 20px;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.1);
      padding: 10px;
      border-radius: 50%;
      transition: background 0.3s;
    }
    .topbar .notification:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    .topbar .profile-btn img {
      width: 35px;
      height: 35px;
      border-radius: 50%;
      cursor: pointer;
      object-fit: cover;
      border: 2px solid white;
    }

    .card {
      background: rgba(177, 178, 167, 0.639);
      margin-bottom: 60px;
      padding: 20px;
      border-radius: 10px;
      font-size: 10px;
      color: #454d42c1;
    }

    .dashboard-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    .highlight {
      font-weight: bold;
      color: #2749bc;
    }

    .chart-section {
      display: flex;
      flex-wrap: wrap;
      gap: 40px;
    }

    canvas {
      background: white;
      border-radius: 10px;
    }
    form {
      all: unset;
      display: contents;
    }

    .table-container {
      overflow-x: auto;
    }

    .employee-table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      border-radius: 8px;
    }

    .employee-table th {
      padding: 15px;
      text-align: left;
      background: #85876a;
      color: white;
    }

    .employee-table td {
      padding: 15px;
      border-bottom: 1px solid #eee;
    }

    .status-badge {
      padding: 5px 10px;
      border-radius: 15px;
      font-size: 12px;
      color: white;
    }

    .status-active {
      background: #70a1ff;
    }

    .status-leave {
      background: #000000;
    }

    .action-btn {
      border: none;
      padding: 5px 10px;
      border-radius: 4px;
      cursor: pointer;
      color: white;
    }

    .edit-btn {
      background: #85876a;
      margin-right: 5px;
    }

    .delete-btn {
      background: #e03f3f;
    }

    .card h2 {
      color: #454d42;
      margin-bottom: 20px;
    }
    
  </style>
</head>
<body>
  <form>
    <div class="container">
      <?php include 'mng_sidebar.html'; ?>
      
      <div class="main">
        <div class="topbar">
          <input
            type="text"
            id="searchInput"
            placeholder="Search employees..."
            style="padding: 8px 12px; font-size: 14px; border-radius: 6px; border: 1px solid #ccc; width: 250px; color: black;"
          />
        </div>

        

        <div class="card">
          <h2>Employee List</h2>
          <div class="table-container">
            <table class="employee-table">
              <thead>
                <tr>
                  <th>Employee ID</th>
                  <th>Name</th>
                  <th>Department</th>
                  <th>Position</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>EMP001</td>
                  <td>John Doe</td>
                  <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                      <div class="circle dev"></div>Development
                    </div>
                  </td>

                  <td>Senior Developer</td>
                  <td><span class="status-badge status-active">Active</span></td>
                </tr>
                <tr>
                  <td>EMP002</td>
                  <td>Jane Smith</td>
                  <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                      <div class="circle art"></div>Art & Design
                    </div>
                  </td>

                  <td>UI Designer</td>
                  <td><span class="status-badge status-active">Active</span></td>
                </tr>
                <tr>
                  <td>EMP003</td>
                  <td>Mike Johnson</td>
                  <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                      <div class="circle dev"></div>Development
                    </div>
                  </td>

                  <td>Project Manager</td>
                  <td><span class="status-badge status-leave">On Leave</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <script>
        function toggleDepartments() {
          const deptList = document.getElementById("departmentList");
          if (deptList.style.display === "none") {
            deptList.style.display = "block";
          } else {
            deptList.style.display = "none"; 
          }    
        }

         document.getElementById("searchInput").addEventListener("keyup", function () {
          const filter = this.value.toLowerCase();
          const rows = document.querySelectorAll(".employee-table tbody tr");

          rows.forEach(row => {
            const text = row.innerText.toLowerCase();
            row.style.display = text.includes(filter) ? "" : "none";
          });
        });
      </script>
      </form>
</body>
</html>

<?php
      }  
  }else{
        header('location: UserAuth.html');
    }
?>

